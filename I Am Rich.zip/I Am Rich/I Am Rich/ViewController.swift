//
//  ViewController.swift
//  I Am Rich
//
//  Created by BMK on 27.09.2024.
//

import UIKit

class ViewController: UIViewController {

    override func viewDidLoad() {
        super.viewDidLoad()
        // Do any additional setup after loading the view.
    }


}

